'use strict';

/**
 * Age of Civilization — client renderer.
 *
 * Follows the Pluto plugin client contract (see games/README.md):
 *   render(api) is called whenever server state pushes an update.
 *   api = { room, game, state, els, E, action, titlebar, logBox, sound }
 *
 * ASSUMPTION (couldn't diff against games/_template/client.js — GitHub's
 * robots.txt blocked the repo's tree view during a web fetch): I'm treating
 * `api.game` as the live serialized server state (the object returned by
 * server.js#serialize), and `api.state` as a small client-local scratch
 * object that survives across re-renders for UI-only concerns (like "which
 * card is currently selected"), since the server never needs to know that.
 * If `_template` actually reverses these two, swap `api.game` <-> `api.state`
 * below — everything else should still hold.
 *
 * ASSUMPTION: mount point is `api.els.board`. If `_template` uses a
 * different key (e.g. `els.root` / `els.container`), rename it in the one
 * spot marked below.
 *
 * ASSUMPTION: `sound(kind)` kind names ('select' | 'build' | 'discard' |
 * 'wave' | 'win' | 'lose' | 'draw') are illustrative — swap for whatever
 * kinds the platform actually defines.
 */

function render(api) {
  const { room, game, state, els, E, action, titlebar, logBox, sound } = api;

  // ASSUMPTION: rename `els.board` if the real template mounts elsewhere.
  const mount = els.board || els.root || els.container;
  mount.innerHTML = '';

  if (!game) return;

  // --- client-local scratch state (persists across renders) ---
  if (state.selectedIdx === undefined) state.selectedIdx = null;
  if (state.lastPhase === undefined) state.lastPhase = null;
  if (state.soundedEnd === undefined) state.soundedEnd = false;

  const ERA_ACCENTS = [
    '#B8895A', '#C9A961', '#9C4A55', '#3E8067', '#7A8062', '#3E9BC9', '#9D6FEF'
  ];

  const root = E('div', 'civ-root');
  root.style.setProperty('--civ-accent', ERA_ACCENTS[(game.age - 1) % ERA_ACCENTS.length]);

  const you = game.players[room.you || Object.keys(game.players).find((id) => game.players[id].isYou)];
  const oppId = game.order.find((id) => id !== you.id);
  const opp = game.players[oppId];

  // reset selection on phase change
  if (state.lastPhase !== game.phase) {
    state.selectedIdx = null;
    state.lastPhase = game.phase;
  }

  titlebar('Age of Civilization', phaseLabel(game, you));

  root.appendChild(renderMonument(E, game));
  root.appendChild(renderEraBanner(E, game));
  root.appendChild(renderStatsRow(E, you, true));
  root.appendChild(renderStatsRow(E, opp, false));
  root.appendChild(renderGridBlock(E, you, 'Jouw Stad'));

  if (game.phase === 'draft') {
    if (!you.acted && game.yourHand.length) {
      root.appendChild(renderDraft(E, action, sound, state, game, you));
    } else {
      const waiting = E('div', 'civ-waiting', `Wachten op ${opp.name}...`);
      root.appendChild(waiting);
    }
  } else if (game.phase === 'wave') {
    root.appendChild(renderWave(E, game, you, opp));
  } else if (game.phase === 'ended') {
    root.appendChild(renderGameOver(E, game, you, opp));
    if (!state.soundedEnd) {
      sound(game.winnerId === you.id ? 'win' : (game.winnerId ? 'lose' : 'draw'));
      state.soundedEnd = true;
    }
  }

  mount.appendChild(root);
  logBox(game.log || []);
}

function phaseLabel(game, you) {
  if (game.phase === 'draft') return you.acted ? `Age ${game.age}/${game.totalAges} — wachten` : `Age ${game.age}/${game.totalAges} — jouw beurt`;
  if (game.phase === 'wave') return `Age ${game.age}/${game.totalAges} — aanval`;
  return 'Spel afgelopen';
}

const ICONS = { military: '🛡', economy: '💰', culture: '🏛', wonder: '✨' };

function renderMonument(E, game) {
  const wrap = E('div', 'civ-monument');
  for (let i = 1; i <= game.totalAges; i++) {
    const cls = i < game.age ? 'civ-tablet done' : (i === game.age ? 'civ-tablet current' : 'civ-tablet');
    const t = E('div', cls, String(i));
    wrap.appendChild(t);
  }
  return wrap;
}

function renderEraBanner(E, game) {
  const wrap = E('div', 'civ-era-banner');
  wrap.appendChild(E('div', 'civ-era-num', `AGE ${game.age} / ${game.totalAges}`));
  wrap.appendChild(E('div', 'civ-era-name', game.eraName));
  return wrap;
}

function renderStatsRow(E, p, isYou) {
  const wrap = E('div', 'civ-stats-row' + (isYou ? ' civ-you' : ' civ-opp'));
  wrap.appendChild(E('div', 'civ-stat-name', (isYou ? 'Jij — ' : '') + p.name + (p.connected === false ? ' (offline)' : '')));
  const boxes = E('div', 'civ-stat-boxes');
  boxes.appendChild(statBox(E, 'Goud', p.gold));
  boxes.appendChild(statBox(E, 'Power', p.power));
  boxes.appendChild(statBox(E, 'VP', p.vp));
  const hpBox = statBox(E, 'Toren', p.hp);
  const bar = E('div', 'civ-hp-track');
  const fill = E('div', 'civ-hp-fill');
  fill.style.width = Math.max(0, p.hp) * 5 + '%';
  bar.appendChild(fill);
  hpBox.appendChild(bar);
  boxes.appendChild(hpBox);
  wrap.appendChild(boxes);
  return wrap;
}

function statBox(E, label, value) {
  const box = E('div', 'civ-stat-box');
  box.appendChild(E('div', 'civ-stat-label', label));
  box.appendChild(E('div', 'civ-stat-value', String(value)));
  return box;
}

function renderGridBlock(E, p, label) {
  const wrap = E('div', 'civ-grid-block');
  wrap.appendChild(E('div', 'civ-grid-label', label));
  const grid = E('div', 'civ-grid');
  p.grid.forEach((c) => {
    const tile = E('div', 'civ-tile' + (c ? ' filled' : ''));
    if (c) {
      tile.appendChild(E('div', 'civ-tile-icon', ICONS[c.type] || ''));
      tile.appendChild(E('div', 'civ-tile-name', c.name));
    }
    grid.appendChild(tile);
  });
  wrap.appendChild(grid);
  return wrap;
}

function renderDraft(E, action, sound, state, game, you) {
  const wrap = E('div', 'civ-draft');
  wrap.appendChild(E('div', 'civ-draft-label', 'Draft — kies er één'));

  const hand = E('div', 'civ-hand');
  game.yourHand.forEach((c) => {
    const card = E('div', 'civ-card' + (c.type === 'wonder' ? ' wonder' : '') + (state.selectedIdx === c.idx ? ' selected' : ''));
    card.appendChild(E('div', 'civ-card-icon', ICONS[c.type] || ''));
    card.appendChild(E('div', 'civ-card-name', c.name));
    card.appendChild(E('div', 'civ-card-cost', `Kost ${c.cost}g`));
    card.addEventListener('click', () => {
      state.selectedIdx = state.selectedIdx === c.idx ? null : c.idx;
      sound('select');
      // Caller (host) is expected to re-render after any state.* mutation;
      // if it doesn't auto-rerender on local state changes, this click
      // handler may need an explicit re-render call here per the real API.
    });
    hand.appendChild(card);
  });
  wrap.appendChild(hand);

  if (state.selectedIdx !== null) {
    const card = game.yourHand.find((c) => c.idx === state.selectedIdx);
    const canBuild = you.gold >= card.cost && you.grid.some((x) => x === null);
    const detail = E('div', 'civ-detail');
    detail.appendChild(E('div', 'civ-detail-name', `${ICONS[card.type]} ${card.name}`));
    detail.appendChild(E('div', 'civ-detail-desc', card.desc));
    const actions = E('div', 'civ-detail-actions');

    const buildBtn = E('button', 'civ-btn civ-btn-primary', `Bouw (${card.cost}g)`);
    if (!canBuild) buildBtn.disabled = true;
    buildBtn.addEventListener('click', () => {
      sound('build');
      action('build', { handIndex: card.idx });
      state.selectedIdx = null;
    });

    const discardBtn = E('button', 'civ-btn civ-btn-ghost', 'Gooi weg (+goud)');
    discardBtn.addEventListener('click', () => {
      sound('discard');
      action('discard', { handIndex: card.idx });
      state.selectedIdx = null;
    });

    actions.appendChild(buildBtn);
    actions.appendChild(discardBtn);
    detail.appendChild(actions);
    wrap.appendChild(detail);
  }

  return wrap;
}

function renderWave(E, game, you, opp) {
  const wrap = E('div', 'civ-wave');
  wrap.appendChild(E('div', 'civ-wave-title', `Age ${game.waveResult.age} Wave — kracht ${game.waveResult.wave}`));
  const cols = E('div', 'civ-wave-cols');
  [you, opp].forEach((p) => {
    const r = game.waveResult.results[p.id];
    const col = E('div', 'civ-wave-col');
    col.appendChild(E('div', 'civ-wave-name', p.name));
    col.appendChild(E('div', 'civ-wave-numbers', `Power ${r.power} vs Wave ${r.wave}`));
    col.appendChild(E('div', 'civ-wave-result' + (r.damage > 0 ? ' hit' : ' ok'),
      r.damage > 0 ? `Toren neemt ${r.damage} schade` : 'Aanval afgeslagen!'));
    cols.appendChild(col);
  });
  wrap.appendChild(cols);
  return wrap;
}

function renderGameOver(E, game, you, opp) {
  const wrap = E('div', 'civ-gameover');
  let headline;
  if (game.endedSuddenDeath) {
    if (!game.winnerId) headline = 'Beide beschavingen vallen — gelijkspel!';
    else headline = game.winnerId === you.id ? 'Jouw toren houdt stand — jij wint!' : `${opp.name}'s toren houdt stand.`;
  } else if (!game.winnerId) {
    headline = 'Gelijkspel na 7 tijdperken!';
  } else {
    headline = game.winnerId === you.id ? 'Jij wint!' : `${opp.name} wint!`;
  }
  wrap.appendChild(E('h2', 'civ-go-headline', headline));

  const table = E('div', 'civ-final-table');
  [you, opp].forEach((p) => {
    const score = game.finalScores ? game.finalScores[p.id] : p.vp;
    const row = E('div', 'civ-final-row' + (game.winnerId === p.id ? ' winner' : ''));
    const info = E('div', '');
    info.appendChild(E('div', 'civ-fname', p.name));
    info.appendChild(E('div', 'civ-breakdown', `VP ${p.vp} + goudbonus ${Math.floor(p.gold / 3)} · Toren ${Math.max(0, p.hp)}/20`));
    row.appendChild(info);
    row.appendChild(E('div', 'civ-fscore', String(score)));
    table.appendChild(row);
  });
  wrap.appendChild(table);
  return wrap;
}

/* ---------------- optional exports ---------------- */

function isWinner(result, playerId) {
  return result.winnerId === playerId;
}

function metric(result, playerId) {
  return result.scores ? (result.scores[playerId] || 0) : 0;
}

function presentResult(result) {
  if (!result.winnerId) return 'Gelijkspel na 7 tijdperken.';
  const name = result.names ? result.names[result.winnerId] : 'Speler';
  return result.suddenDeath ? `${name} wint doordat de tegenstander se toren viel.` : `${name} wint op punten.`;
}

module.exports = { render, isWinner, metric, presentResult };
